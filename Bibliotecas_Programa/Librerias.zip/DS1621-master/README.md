# DS1621

This is a little Arduino library that will talk to a DS1621 temperature sensor over I2C.

It depends on the Wire library.
